# my package
This is a library for doing something.

## Installation
You can install it via pip:
```bash
pip install my_package
```